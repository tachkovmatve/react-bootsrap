import Spinner from 'react-bootstrap/Spinner';

function BorderExample() {
  return <Spinner animation="border" />;
}

export default BorderExample;
