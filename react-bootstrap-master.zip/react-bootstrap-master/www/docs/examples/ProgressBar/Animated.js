import ProgressBar from 'react-bootstrap/ProgressBar';

function AnimatedExample() {
  return <ProgressBar animated now={45} />;
}

export default AnimatedExample;
